import boto3
import base64
from Crypto.PublicKey import RSA
import base64
import cfnresponse
import logging

def lambda_handler(event, context):
    response = ""
    try:
        cfn = cfnresponse.SUCCESS
        name = event['ResourceProperties']['Name']
        logger = logging.getLogger(__name__)
        client = boto3.client('secretsmanager')
        secret = client.list_secrets(Filters=[{'Key':'name', 'Values':[name]}])
        if len(secret['SecretList']) == 0:
            key = RSA.generate(2048)
            priv = base64.b64encode(key.exportKey('PEM')).decode("utf-8")
            pubkey = key.publickey()
            pub = base64.b64encode(pubkey.exportKey('OpenSSH')).decode("utf-8")
            response = client.create_secret(
                Name=name,
                Description='SSH Key used for JWT token in 3decision quickstart',
                SecretString='{"private_key": ' + f"\"{priv}\"" + ', "public_key": ' + f"\"{pub}\"" + '}',
            )
        else:
            logger.warning('3dec JWT ssh key already existed, using that one.')
    except Exception as e:
        logger.warning('Did not create 3dec JWT ssh key: {}'.format(e))
        cfn = cfnresponse.FAILED
    finally:
        cfnresponse.send(event, context, cfn, {}, "".format(response))